RTOS Benchmark - Phase 1 raw logs (publishable subset)
======================================================

Source tree for reproduction: https://github.com/chibilogic/rtos-benchmark/tree/phase1-v1.0
Pair these raw logs with exactly that source tree.

Contents (under results/):
  raw/<rtos>_<profile>_run0[1-5].csv          per-iteration cycles
  raw/<rtos>_<profile>_run0[1-5].t4_pi.csv    T4 priority-inheritance
  raw/<rtos>_<profile>_run0[1-5].banner.txt   boot register witness
  raw/<rtos>_<profile>_run0[1-5].validated.json  per-run gate result
  raw/<rtos>_<profile>_run01.elf              firmware (SHA check)
  manifest/<profile>_campaign.lock.json       ELF/MAP/loadable SHA-256
  summary/                                    published aggregates
  README.md                                   raw-log format reference
  LICENSE, LICENSES/, NOTICE.txt              license texts + binary
                                              distribution notices

Excluded: run00 warmup, stdout/collector logs, plots, archived
datasets, and the .map files (their map_sha256 stays in the campaign
lock for anyone who rebuilds).

Verify firmware identity (ADR-025): rebuild from the paired source
tree with the official toolchain and the publication-mode AUTORUN,
then compare the loadable image (arm-none-eabi-objcopy -O binary,
sha256) to loadable_image_sha256 in
results/manifest/<profile>_campaign.lock.json. The shipped run01 .elf
also matches elf_sha256; the full ELF/MAP SHA may differ only in
DWARF/debug after source comment edits.
Recompute medians: per-run CSVs use the sorted-index percentile
(ADR-013); see scripts/analyze_results.py and report_results.py in
the code repository. MANIFEST.sha256 lists the sha256 of every file.

Paths: the textual/JSON path fields are repo-relative. The only
absolute paths in this archive are inside the six run01 .elf files
(DWARF debug info / toolchain paths) -- benign build provenance, no
secrets, intrinsic to the SHA-pinned measured binaries, not rewritten.
