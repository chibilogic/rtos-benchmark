# Run summary - zephyr / realistic_tickless / run 01

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `zephyr` |
| RTOS kernel | `Zephyr 4.4.0` |
| Profile | `realistic_tickless` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   575 |    581 |   579 |   582 |   614 |   616 |     41 |      5 |       1.210 |    1.279 |
| t2_handoff    | 10000 |   422 |    424 |   424 |   424 |   424 |   439 |     17 |      0 |       0.883 |    0.883 |
| t3_mtx_uncont | 10000 |   125 |    125 |   125 |   125 |   125 |   140 |     15 |      0 |       0.260 |    0.260 |
| t4_mtx_pi     |   100 |   677 |    677 |   680 |   686 |   715 |   715 |     38 |      5 |       1.410 |    1.490 |

**T4 priority inheritance**: 100 / 100 passed.
