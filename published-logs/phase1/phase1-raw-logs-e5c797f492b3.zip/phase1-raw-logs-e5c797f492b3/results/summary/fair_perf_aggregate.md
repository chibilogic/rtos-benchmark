# Aggregate summary - profile `fair_perf`

Each cell is the **median across the N runs** of that stat field (ADR-013 multi-run rule). A single bad run cannot bias the published number.

CPU clock assumed: 480 MHz

## RTOS kernels (this profile)

| rtos | kernel | consistent across runs |
|------|--------|------------------------|
| chibios | `ChibiOS RT 7.0.6` | yes |
| freertos | `FreeRTOS V11.3.0` | yes |
| zephyr | `Zephyr 4.4.0` | yes |

| rtos     | test          | source           | n_runs | median | p95 | p99 | max | jitter | run_min | run_max | run_spread | mean | stddev | median (us) | p99 (us) |
|----------|---------------|------------------|-------:|-------:|----:|----:|----:|-------:|--------:|--------:|-----------:|-----:|-------:|------------:|---------:|
| chibios  | t1_irq        | DWT              |      5 |    297 | 303 | 303 | 318 |     34 |     297 |     297 |          0 |  295 |      6 |       0.619 |    0.631 |
| chibios  | t2_handoff    | DWT              |      5 |     93 |  94 |  94 | 110 |     18 |      93 |      93 |          0 |   93 |      0 |       0.194 |    0.196 |
| chibios  | t3_mtx_uncont | DWT              |      5 |     62 |  64 |  64 | 403 |    341 |      62 |      62 |          0 |   62 |      3 |       0.129 |    0.133 |
| chibios  | t4_mtx_pi     | DWT              |      5 |    200 | 200 | 220 | 220 |     20 |     200 |     200 |          0 |  200 |      2 |       0.417 |    0.458 |
| freertos | t1_irq        | DWT              |      5 |    440 | 447 | 447 | 459 |     27 |     440 |     440 |          0 |  439 |      4 |       0.917 |    0.931 |
| freertos | t2_handoff    | DWT              |      5 |    370 | 379 | 385 | 551 |    197 |     370 |     370 |          0 |  369 |      7 |       0.771 |    0.802 |
| freertos | t3_mtx_uncont | DWT              |      5 |    202 | 216 | 223 | 429 |    233 |     202 |     202 |          0 |  206 |      6 |       0.421 |    0.465 |
| freertos | t4_mtx_pi     | DWT              |      5 |    599 | 599 | 632 | 632 |     33 |     599 |     599 |          0 |  599 |      3 |       1.248 |    1.317 |
| zephyr   | t1_irq        | DWT              |      5 |    624 | 630 | 635 | 649 |     54 |     624 |     624 |          0 |  615 |     14 |       1.300 |    1.323 |
| zephyr   | t2_handoff    | DWT              |      5 |    425 | 425 | 425 | 641 |    221 |     425 |     425 |          0 |  425 |      6 |       0.885 |    0.885 |
| zephyr   | t3_mtx_uncont | DWT              |      5 |    124 | 124 | 124 | 442 |    318 |     124 |     124 |          0 |  124 |      4 |       0.258 |    0.258 |
| zephyr   | t4_mtx_pi     | DWT              |      5 |    722 | 722 | 766 | 766 |     44 |     722 |     722 |          0 |  722 |      4 |       1.504 |    1.596 |

## T4 priority inheritance - aggregate

| rtos     | passed / total |
|----------|---------------:|
| chibios  | 500 / 500 |
| freertos | 500 / 500 |
| zephyr   | 500 / 500 |
