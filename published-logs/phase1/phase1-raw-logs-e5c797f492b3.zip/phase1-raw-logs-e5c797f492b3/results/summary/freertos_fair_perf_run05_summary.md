# Run summary - freertos / fair_perf / run 05

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `freertos` |
| RTOS kernel | `FreeRTOS V11.3.0` |
| Profile | `fair_perf` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   432 |    440 |   439 |   447 |   447 |   459 |     27 |      4 |       0.917 |    0.931 |
| t2_handoff    | 10000 |   354 |    370 |   369 |   379 |   385 |   551 |    197 |      7 |       0.771 |    0.802 |
| t3_mtx_uncont | 10000 |   196 |    202 |   206 |   216 |   223 |   429 |    233 |      6 |       0.421 |    0.465 |
| t4_mtx_pi     |   100 |   599 |    599 |   599 |   599 |   632 |   632 |     33 |      3 |       1.248 |    1.317 |

**T4 priority inheritance**: 100 / 100 passed.
