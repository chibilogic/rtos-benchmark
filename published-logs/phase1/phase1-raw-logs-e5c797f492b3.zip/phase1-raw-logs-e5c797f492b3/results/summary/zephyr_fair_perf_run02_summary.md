# Run summary - zephyr / fair_perf / run 02

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `zephyr` |
| RTOS kernel | `Zephyr 4.4.0` |
| Profile | `fair_perf` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   595 |    624 |   615 |   630 |   635 |   649 |     54 |     14 |       1.300 |    1.323 |
| t2_handoff    | 10000 |   420 |    425 |   425 |   425 |   425 |   641 |    221 |      6 |       0.885 |    0.885 |
| t3_mtx_uncont | 10000 |   124 |    124 |   124 |   124 |   124 |   442 |    318 |      4 |       0.258 |    0.258 |
| t4_mtx_pi     |   100 |   722 |    722 |   722 |   722 |   766 |   766 |     44 |      4 |       1.504 |    1.596 |

**T4 priority inheritance**: 100 / 100 passed.
