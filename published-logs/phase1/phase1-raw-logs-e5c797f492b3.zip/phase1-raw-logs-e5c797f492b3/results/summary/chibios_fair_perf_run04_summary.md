# Run summary - chibios / fair_perf / run 04

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `chibios` |
| RTOS kernel | `ChibiOS RT 7.0.6` |
| Profile | `fair_perf` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   284 |    297 |   295 |   303 |   303 |   318 |     34 |      6 |       0.619 |    0.631 |
| t2_handoff    | 10000 |    92 |     93 |    93 |    94 |    94 |   110 |     18 |      0 |       0.194 |    0.196 |
| t3_mtx_uncont | 10000 |    62 |     62 |    62 |    64 |    64 |   403 |    341 |      3 |       0.129 |    0.133 |
| t4_mtx_pi     |   100 |   200 |    200 |   200 |   200 |   220 |   220 |     20 |      2 |       0.417 |    0.458 |

**T4 priority inheritance**: 100 / 100 passed.
