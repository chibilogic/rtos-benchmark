# Cross-RTOS compare - profile `fair_perf`

**Source attribution - Phase 1 (DWT-only):** every latency number in this report is computed via the DWT cycle counter inside the firmware. TEST 1 corresponds to `A4 - A1` (`ISR_ENTRY -> THREAD_RUNNING`, metric `dwt_a4_minus_a1`); the hardware-event-to-ISR-entry component (timer compare match, NVIC entry, stacking, vectoring, ISR prologue) is EXCLUDED. These figures must NOT be quoted as the external IRQ-to-thread latency or as an LA-equivalent measurement. See ADR-015.

Median across runs, in cycles. `(us)` columns at the right convert via 480 MHz CPU clock.

## Kernels

| rtos | kernel |
|------|--------|
| chibios | `ChibiOS RT 7.0.6` |
| freertos | `FreeRTOS V11.3.0` |
| zephyr | `Zephyr 4.4.0` |

| test | metric | chibios | freertos | zephyr | chibios (us) | freertos (us) | zephyr (us) |
|----|----|---:|---:|---:|---:|---:|---:|
| t1_irq | median | 297 | 440 | 624 | 0.619 | 0.917 | 1.300 |
| t1_irq | p95 | 303 | 447 | 630 | 0.631 | 0.931 | 1.312 |
| t1_irq | p99 | 303 | 447 | 635 | 0.631 | 0.931 | 1.323 |
| t1_irq | max | 318 | 459 | 649 | 0.662 | 0.956 | 1.352 |
| t1_irq | jitter | 34 | 27 | 54 | 0.071 | 0.056 | 0.113 |
| t2_handoff | median | 93 | 370 | 425 | 0.194 | 0.771 | 0.885 |
| t2_handoff | p95 | 94 | 379 | 425 | 0.196 | 0.790 | 0.885 |
| t2_handoff | p99 | 94 | 385 | 425 | 0.196 | 0.802 | 0.885 |
| t2_handoff | max | 110 | 551 | 641 | 0.229 | 1.148 | 1.335 |
| t2_handoff | jitter | 18 | 197 | 221 | 0.037 | 0.410 | 0.460 |
| t3_mtx_uncont | median | 62 | 202 | 124 | 0.129 | 0.421 | 0.258 |
| t3_mtx_uncont | p95 | 64 | 216 | 124 | 0.133 | 0.450 | 0.258 |
| t3_mtx_uncont | p99 | 64 | 223 | 124 | 0.133 | 0.465 | 0.258 |
| t3_mtx_uncont | max | 403 | 429 | 442 | 0.840 | 0.894 | 0.921 |
| t3_mtx_uncont | jitter | 341 | 233 | 318 | 0.710 | 0.485 | 0.662 |
| t4_mtx_pi | median | 200 | 599 | 722 | 0.417 | 1.248 | 1.504 |
| t4_mtx_pi | p95 | 200 | 599 | 722 | 0.417 | 1.248 | 1.504 |
| t4_mtx_pi | p99 | 220 | 632 | 766 | 0.458 | 1.317 | 1.596 |
| t4_mtx_pi | max | 220 | 632 | 766 | 0.458 | 1.317 | 1.596 |
| t4_mtx_pi | jitter | 20 | 33 | 44 | 0.042 | 0.069 | 0.092 |
