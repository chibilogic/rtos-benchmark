# Overview - profile `realistic_tickless`

- publication-gated = yes
- publication mode = dwt_only
- Campaign lock timestamp: 2026-05-22T11:26:40.990747+00:00

**Source attribution - Phase 1 (DWT-only):** every latency number in this report is computed via the DWT cycle counter inside the firmware. TEST 1 corresponds to `A4 - A1` (`ISR_ENTRY -> THREAD_RUNNING`, metric `dwt_a4_minus_a1`); the hardware-event-to-ISR-entry component (timer compare match, NVIC entry, stacking, vectoring, ISR prologue) is EXCLUDED. These figures must NOT be quoted as the external IRQ-to-thread latency or as an LA-equivalent measurement. See ADR-015.

## Configuration snapshot

| field | chibios | freertos | zephyr |
|----|---|---|---|
| kernel | ChibiOS RT 7.0.6 | FreeRTOS V11.3.0 | Zephyr 4.4.0 |
| system_clock | 480000000 Hz | 480000000 Hz | 480000000 Hz |
| vos_level | VOS0 | VOS0 | VOS0 |
| vosrdy | READY | READY | READY |
| flash_acr | 0x00000034 | 0x00000034 | 0x00000034 |
| icache | ON | ON | ON |
| dcache | ON | ON | ON |
| tickless | ON | ON | ON |
| wfi_in_idle | ON | ON | ON |
| optimization | -O2  LTO=no | -O2  LTO=no | -O2  LTO=no |
| elf_sha256 | `536da90f...` | `a35ed973...` | `d60d8a90...` |

## Headline - median-of-medians per (rtos, test)

| rtos     | test          | median (cyc) | median (us) | p99 (cyc) | p99 (us) | run_spread (cyc) | source           |
|----------|---------------|-------------:|------------:|----------:|---------:|-----------------:|------------------|
| chibios  | t1_irq        |          306 |       0.637 |       324 |    0.675 |                0 | DWT              |
| chibios  | t2_handoff    |           95 |       0.198 |        96 |    0.200 |                0 | DWT              |
| chibios  | t3_mtx_uncont |           62 |       0.129 |        64 |    0.133 |                0 | DWT              |
| chibios  | t4_mtx_pi     |          200 |       0.417 |       219 |    0.456 |                0 | DWT              |
| freertos | t1_irq        |          846 |       1.762 |       850 |    1.771 |                0 | DWT              |
| freertos | t2_handoff    |          376 |       0.783 |       417 |    0.869 |                0 | DWT              |
| freertos | t3_mtx_uncont |          195 |       0.406 |       196 |    0.408 |                0 | DWT              |
| freertos | t4_mtx_pi     |          612 |       1.275 |       641 |    1.335 |                0 | DWT              |
| zephyr   | t1_irq        |          581 |       1.210 |       614 |    1.279 |                0 | DWT              |
| zephyr   | t2_handoff    |          424 |       0.883 |       424 |    0.883 |                0 | DWT              |
| zephyr   | t3_mtx_uncont |          125 |       0.260 |       125 |    0.260 |                0 | DWT              |
| zephyr   | t4_mtx_pi     |          677 |       1.410 |       715 |    1.490 |                0 | DWT              |

## TEST 4 priority inheritance

| rtos     | passed / total |
|----------|---------------:|
| chibios  | 500 / 500 |
| freertos | 500 / 500 |
| zephyr   | 500 / 500 |

## Details

- Per-run summaries: `<rtos>_realistic_tickless_run0[1-5]_summary.md`
- Aggregate: `realistic_tickless_aggregate.md` / `realistic_tickless_aggregate.csv`
- Compare: `realistic_tickless_compare.md`
- Charts: `../plots/realistic_tickless_*.png`
- Campaign lock: `../manifest/realistic_tickless_campaign.lock.json`
