# Run summary - chibios / realistic_tickless / run 04

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `chibios` |
| RTOS kernel | `ChibiOS RT 7.0.6` |
| Profile | `realistic_tickless` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   286 |    306 |   305 |   322 |   324 |   328 |     42 |      7 |       0.637 |    0.675 |
| t2_handoff    | 10000 |    94 |     95 |    94 |    96 |    96 |   110 |     16 |      1 |       0.198 |    0.200 |
| t3_mtx_uncont | 10000 |    62 |     62 |    62 |    64 |    64 |    77 |     15 |      0 |       0.129 |    0.133 |
| t4_mtx_pi     |   100 |   200 |    200 |   200 |   200 |   219 |   219 |     19 |      1 |       0.417 |    0.456 |

**T4 priority inheritance**: 100 / 100 passed.
