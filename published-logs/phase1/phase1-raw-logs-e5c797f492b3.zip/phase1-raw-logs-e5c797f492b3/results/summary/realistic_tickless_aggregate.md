# Aggregate summary - profile `realistic_tickless`

Each cell is the **median across the N runs** of that stat field (ADR-013 multi-run rule). A single bad run cannot bias the published number.

CPU clock assumed: 480 MHz

## RTOS kernels (this profile)

| rtos | kernel | consistent across runs |
|------|--------|------------------------|
| chibios | `ChibiOS RT 7.0.6` | yes |
| freertos | `FreeRTOS V11.3.0` | yes |
| zephyr | `Zephyr 4.4.0` | yes |

| rtos     | test          | source           | n_runs | median | p95 | p99 | max | jitter | run_min | run_max | run_spread | mean | stddev | median (us) | p99 (us) |
|----------|---------------|------------------|-------:|-------:|----:|----:|----:|-------:|--------:|--------:|-----------:|-----:|-------:|------------:|---------:|
| chibios  | t1_irq        | DWT              |      5 |    306 | 322 | 324 | 328 |     42 |     306 |     306 |          0 |  305 |      7 |       0.637 |    0.675 |
| chibios  | t2_handoff    | DWT              |      5 |     95 |  96 |  96 | 110 |     16 |      95 |      95 |          0 |   94 |      1 |       0.198 |    0.200 |
| chibios  | t3_mtx_uncont | DWT              |      5 |     62 |  64 |  64 |  77 |     15 |      62 |      62 |          0 |   62 |      0 |       0.129 |    0.133 |
| chibios  | t4_mtx_pi     | DWT              |      5 |    200 | 200 | 219 | 219 |     19 |     200 |     200 |          0 |  200 |      1 |       0.417 |    0.456 |
| freertos | t1_irq        | DWT              |      5 |    846 | 848 | 850 | 1027 |    202 |     846 |     846 |          0 |  837 |     11 |       1.762 |    1.771 |
| freertos | t2_handoff    | DWT              |      5 |    376 | 397 | 417 | 566 |    208 |     376 |     376 |          0 |  379 |     15 |       0.783 |    0.869 |
| freertos | t3_mtx_uncont | DWT              |      5 |    195 | 195 | 196 | 387 |    194 |     195 |     195 |          0 |  194 |      3 |       0.406 |    0.408 |
| freertos | t4_mtx_pi     | DWT              |      5 |    612 | 616 | 641 | 641 |     29 |     612 |     612 |          0 |  612 |      3 |       1.275 |    1.335 |
| zephyr   | t1_irq        | DWT              |      5 |    581 | 582 | 614 | 616 |     41 |     581 |     581 |          0 |  579 |      5 |       1.210 |    1.279 |
| zephyr   | t2_handoff    | DWT              |      5 |    424 | 424 | 424 | 439 |     17 |     424 |     424 |          0 |  424 |      0 |       0.883 |    0.883 |
| zephyr   | t3_mtx_uncont | DWT              |      5 |    125 | 125 | 125 | 140 |     15 |     125 |     125 |          0 |  125 |      0 |       0.260 |    0.260 |
| zephyr   | t4_mtx_pi     | DWT              |      5 |    677 | 686 | 715 | 715 |     38 |     677 |     677 |          0 |  680 |      5 |       1.410 |    1.490 |

## T4 priority inheritance - aggregate

| rtos     | passed / total |
|----------|---------------:|
| chibios  | 500 / 500 |
| freertos | 500 / 500 |
| zephyr   | 500 / 500 |
