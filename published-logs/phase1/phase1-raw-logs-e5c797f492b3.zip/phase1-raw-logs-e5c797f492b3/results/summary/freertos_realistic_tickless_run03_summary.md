# Run summary - freertos / realistic_tickless / run 03

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `freertos` |
| RTOS kernel | `FreeRTOS V11.3.0` |
| Profile | `realistic_tickless` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   825 |    846 |   837 |   848 |   850 |  1027 |    202 |     11 |       1.762 |    1.771 |
| t2_handoff    | 10000 |   358 |    376 |   379 |   397 |   417 |   566 |    208 |     15 |       0.783 |    0.869 |
| t3_mtx_uncont | 10000 |   193 |    195 |   194 |   195 |   196 |   387 |    194 |      3 |       0.406 |    0.408 |
| t4_mtx_pi     |   100 |   612 |    612 |   612 |   616 |   641 |   641 |     29 |      3 |       1.275 |    1.335 |

**T4 priority inheritance**: 100 / 100 passed.
