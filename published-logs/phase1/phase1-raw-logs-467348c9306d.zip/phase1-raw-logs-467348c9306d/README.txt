RTOS Benchmark - Phase 1 raw logs (publishable subset)
======================================================

Source tree for reproduction: https://github.com/chibilogic/rtos-benchmark/tree/phase1-v1.0
Pair these raw logs with exactly that source tree.

Contents (under results/):
  raw/<rtos>_<profile>_run0[1-5].csv          per-iteration cycles
  raw/<rtos>_<profile>_run0[1-5].t4_pi.csv    T4 priority-inheritance
  raw/<rtos>_<profile>_run0[1-5].banner.txt   boot register witness
  raw/<rtos>_<profile>_run0[1-5].validated.json  per-run gate result
  raw/<rtos>_<profile>_run01.{elf,map}        firmware (SHA check)
  manifest/<profile>_campaign.lock.json       ELF/MAP SHA-256 locks
  summary/                                    published aggregates
  README.md                                   raw-log format reference

Excluded: run00 warmup, stdout/collector logs, plots, archived
datasets.

Verify firmware identity: sha256 of
results/raw/<rtos>_<profile>_run01.elf must equal elf_sha256 in
results/manifest/<profile>_campaign.lock.json.
Recompute medians: per-run CSVs use the sorted-index percentile
(ADR-013); see scripts/analyze_results.py and report_results.py in
the code repository. MANIFEST.sha256 lists the sha256 of every file.

Note: lock and footprint JSON files embed absolute paths from the
original lab host (e.g. D:\CHIBILOGIC\...). These are the
unmodified build-provenance paths, deliberately not rewritten.
