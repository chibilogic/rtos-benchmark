# Firmware footprint -- profile `fair_perf`

Metric definition per ADR-023 (binding):
- **Code size** = `.text + .rodata` (PROGBITS sections in flash, ALLOC set, not writable). Bundles kernel + HAL + libc; see libc disclaimer below.
- **Static RAM used** = `.data + .bss + noinit` (ALLOC+WRITE PROGBITS + NOBITS in RAM), with the ChibiOS `.heap` linker-script reservation excluded (`CH_CFG_USE_HEAP=FALSE`, the region holds no allocation), PLUS per-RTOS extra committed-stack reservations not visible as labelled sections (Codex round 2 IMP-1 fix): ChibiOS DTCM `__main_stack_size__` + `__process_stack_size__` (2 KB), FreeRTOS `_Min_Stack_Size` (4 KB main stack reservation in AXI SRAM). Zephyr already covers all thread stacks via the `noinit` section, so no extra add is needed.
- **Tail reservation** is informational only: spare RAM kept available for the descending main stack (FreeRTOS), k_thread_create runtime stacks (Zephyr), or the linker heap reservation (ChibiOS). For FreeRTOS the reported tail EXCLUDES `_Min_Stack_Size` (counted in static RAM used).


## Headline

| RTOS | code size (B) | static RAM used (B) | tail reservation (B, info) |
| --- | ---: | ---: | ---: |
| chibios | 24612 | 229984 | 298400 |
| freertos | 31716 | 252776 | 276632 |
| zephyr | 45508 | 236185 | 288000 |

## libc disclaimer (ADR-009)

The three RTOSes intentionally link three different libc implementations (ADR-009 sec. "Linker flags"):
- ChibiOS  : newlib full (no `--specs=nano.specs`); ChibiOS supplies its own startup and syscall stubs.
- FreeRTOS : newlib-nano via `--specs=nano.specs --specs=nosys.specs`.
- Zephyr   : picolibc (Zephyr default at v4.4.0).
The code-size number above bundles kernel + HAL + libc and is NOT a pure kernel-text comparison. A per-archive breakdown is a follow-up deliverable (`footprint.py --by-archive`).


## Per-ELF detail

### chibios fair_perf

- ELF: `D:\CHIBILOGIC\ChibiOS\rtos-benchmark\results\raw\chibios_fair_perf_run01.elf`
- ELF source: raw
- SHA-256: `18ad62d06bbd856f2b662c97d13a98db53f46715c0063ebb087af5346fcfea39`
- Campaign-lock SHA match: yes
- ELF on disk: 341108 bytes
- Code (text+rodata-like): 24612 B
  - sections:
    - .vectors @ 0x08000000: 736 B
    - .text @ 0x08000300: 21076 B
    - .rodata @ 0x08005554: 2800 B
- RAM data (PROGBITS+AW): 336 B
- RAM bss raw (NOBITS+AW total): 526000 B
- RAM bss excluded (.heap): 298400 B
- RAM extra committed stacks: 2048 B (__main_stack_size__=1024, __process_stack_size__=1024)
- Static RAM used (data + bss - excluded + extra-stacks): 229984 B
- Tail reservation (__heap_end__ - __heap_base__): 298400 B

### freertos fair_perf

- ELF: `D:\CHIBILOGIC\ChibiOS\rtos-benchmark\results\raw\freertos_fair_perf_run01.elf`
- ELF source: raw
- SHA-256: `8410f98d6dc145805975eb65208f00fdf9002c82b4af5a77a69d8b948c7a9b05`
- Campaign-lock SHA match: yes
- ELF on disk: 472204 bytes
- Code (text+rodata-like): 31716 B
  - sections:
    - .isr_vector @ 0x08000000: 664 B
    - .text @ 0x080002a0: 28320 B
    - .rodata @ 0x08007140: 2732 B
- RAM data (PROGBITS+AW): 24 B
- RAM bss raw (NOBITS+AW total): 248656 B
- RAM extra committed stacks: 4096 B (_Min_Stack_Size=4096)
- Static RAM used (data + bss - excluded + extra-stacks): 252776 B
- Tail reservation (_estack - __bss_end__ - _Min_Stack_Size): 276632 B

### zephyr fair_perf

- ELF: `D:\CHIBILOGIC\ChibiOS\rtos-benchmark\results\raw\zephyr_fair_perf_run01.elf`
- ELF source: raw
- SHA-256: `0e175ae3127c194b2f7528622e82574aa39d7951c56542619a2f62da227277ac`
- Campaign-lock SHA match: yes
- ELF on disk: 903564 bytes
- Code (text+rodata-like): 45508 B
  - sections:
    - rom_start @ 0x08000000: 576 B
    - text @ 0x08000240: 37568 B
    - initlevel @ 0x08009508: 168 B
    - device_area @ 0x080095b0: 448 B
    - sw_isr_table @ 0x08009770: 1024 B
    - gpio_driver_api_area @ 0x08009b70: 36 B
    - reset_driver_api_area @ 0x08009b94: 16 B
    - clock_control_driver_api_area @ 0x08009ba4: 28 B
    - uart_driver_api_area @ 0x08009bc0: 20 B
    - rodata @ 0x08009bd8: 5624 B
- RAM data (PROGBITS+AW): 128 B
- RAM bss raw (NOBITS+AW total): 236057 B
- Static RAM used (data + bss - excluded + extra-stacks): 236185 B
- Tail reservation (__kernel_ram_end - _end): 288000 B
