# Firmware footprint -- profile `realistic_tickless`

Metric definition per ADR-023 (binding):
- **Code size** = `.text + .rodata` (PROGBITS sections in flash, ALLOC set, not writable). Bundles kernel + HAL + libc; see libc disclaimer below.
- **Static RAM used** = `.data + .bss + noinit` (ALLOC+WRITE PROGBITS + NOBITS in RAM), with the ChibiOS `.heap` linker-script reservation excluded (`CH_CFG_USE_HEAP=FALSE`, the region holds no allocation), PLUS per-RTOS extra committed-stack reservations not visible as labelled sections (Codex round 2 IMP-1 fix): ChibiOS DTCM `__main_stack_size__` + `__process_stack_size__` (2 KB), FreeRTOS `_Min_Stack_Size` (4 KB main stack reservation in AXI SRAM). Zephyr already covers all thread stacks via the `noinit` section, so no extra add is needed.
- **Tail reservation** is informational only: spare RAM kept available for the descending main stack (FreeRTOS), k_thread_create runtime stacks (Zephyr), or the linker heap reservation (ChibiOS). For FreeRTOS the reported tail EXCLUDES `_Min_Stack_Size` (counted in static RAM used).


## Headline

| RTOS | code size (B) | static RAM used (B) | tail reservation (B, info) |
| --- | ---: | ---: | ---: |
| chibios | 25256 | 229984 | 298400 |
| freertos | 32396 | 252784 | 276624 |
| zephyr | 45936 | 236193 | 288000 |

## libc disclaimer (ADR-009)

The three RTOSes intentionally link three different libc implementations (ADR-009 sec. "Linker flags"):
- ChibiOS  : newlib full (no `--specs=nano.specs`); ChibiOS supplies its own startup and syscall stubs.
- FreeRTOS : newlib-nano via `--specs=nano.specs --specs=nosys.specs`.
- Zephyr   : picolibc (Zephyr default at v4.4.0).
The code-size number above bundles kernel + HAL + libc and is NOT a pure kernel-text comparison. A per-archive breakdown is a follow-up deliverable (`footprint.py --by-archive`).


## Per-ELF detail

### chibios realistic_tickless

- ELF: `D:\CHIBILOGIC\ChibiOS\rtos-benchmark\results\raw\chibios_realistic_tickless_run01.elf`
- ELF source: raw
- SHA-256: `536da90f60dec5f9ed8c426ce39e31eddcc8bb41c08fd8fed7c19b62f99a89d7`
- Campaign-lock SHA match: yes
- ELF on disk: 356820 bytes
- Code (text+rodata-like): 25256 B
  - sections:
    - .vectors @ 0x08000000: 736 B
    - .text @ 0x08000300: 21716 B
    - .rodata @ 0x080057d4: 2804 B
- RAM data (PROGBITS+AW): 336 B
- RAM bss raw (NOBITS+AW total): 526000 B
- RAM bss excluded (.heap): 298400 B
- RAM extra committed stacks: 2048 B (__main_stack_size__=1024, __process_stack_size__=1024)
- Static RAM used (data + bss - excluded + extra-stacks): 229984 B
- Tail reservation (__heap_end__ - __heap_base__): 298400 B

### freertos realistic_tickless

- ELF: `D:\CHIBILOGIC\ChibiOS\rtos-benchmark\results\raw\freertos_realistic_tickless_run01.elf`
- ELF source: raw
- SHA-256: `a35ed9733625b2682749ee8ca7261db9e0a68e9fab7c392cef8691e18124f141`
- Campaign-lock SHA match: yes
- ELF on disk: 476376 bytes
- Code (text+rodata-like): 32396 B
  - sections:
    - .isr_vector @ 0x08000000: 664 B
    - .text @ 0x080002a0: 28992 B
    - .rodata @ 0x080073e0: 2740 B
- RAM data (PROGBITS+AW): 24 B
- RAM bss raw (NOBITS+AW total): 248664 B
- RAM extra committed stacks: 4096 B (_Min_Stack_Size=4096)
- Static RAM used (data + bss - excluded + extra-stacks): 252784 B
- Tail reservation (_estack - __bss_end__ - _Min_Stack_Size): 276624 B

### zephyr realistic_tickless

- ELF: `D:\CHIBILOGIC\ChibiOS\rtos-benchmark\results\raw\zephyr_realistic_tickless_run01.elf`
- ELF source: raw
- SHA-256: `d60d8a90927c70c3f70cce025304f645fc708c24dc832c68a4ec7593cfbb256d`
- Campaign-lock SHA match: yes
- ELF on disk: 908604 bytes
- Code (text+rodata-like): 45936 B
  - sections:
    - rom_start @ 0x08000000: 576 B
    - text @ 0x08000240: 37988 B
    - initlevel @ 0x080096ac: 168 B
    - device_area @ 0x08009754: 448 B
    - sw_isr_table @ 0x08009914: 1024 B
    - gpio_driver_api_area @ 0x08009d14: 36 B
    - reset_driver_api_area @ 0x08009d38: 16 B
    - clock_control_driver_api_area @ 0x08009d48: 28 B
    - uart_driver_api_area @ 0x08009d64: 20 B
    - rodata @ 0x08009d78: 5632 B
- RAM data (PROGBITS+AW): 128 B
- RAM bss raw (NOBITS+AW total): 236065 B
- Static RAM used (data + bss - excluded + extra-stacks): 236193 B
- Tail reservation (__kernel_ram_end - _end): 288000 B
