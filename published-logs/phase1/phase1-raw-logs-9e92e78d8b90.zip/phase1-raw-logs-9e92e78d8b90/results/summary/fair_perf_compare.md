# Cross-RTOS compare - profile `fair_perf`

**Source attribution - Phase 1 (DWT-only):** every latency number in this report is computed via the DWT cycle counter inside the firmware. TEST 1 corresponds to `A4 - A1` (`ISR_ENTRY -> THREAD_RUNNING`, metric `dwt_a4_minus_a1`); the hardware-event-to-ISR-entry component (timer compare match, NVIC entry, stacking, vectoring, ISR prologue) is EXCLUDED. These figures must NOT be quoted as the external IRQ-to-thread latency or as an LA-equivalent measurement. See ADR-015.

Median across runs, in cycles. `(us)` columns at the right convert via 480 MHz CPU clock.

## Kernels

| rtos | kernel |
|------|--------|
| chibios | `ChibiOS RT 7.0.6` |
| freertos | `FreeRTOS V11.3.0` |
| zephyr | `Zephyr 4.4.0` |

| test | metric | chibios | freertos | zephyr | chibios (us) | freertos (us) | zephyr (us) |
|----|----|---:|---:|---:|---:|---:|---:|
| t1_irq | median | 298 | 440 | 624 | 0.621 | 0.917 | 1.300 |
| t1_irq | p95 | 303 | 447 | 630 | 0.631 | 0.931 | 1.312 |
| t1_irq | p99 | 305 | 447 | 635 | 0.635 | 0.931 | 1.323 |
| t1_irq | max | 319 | 459 | 649 | 0.665 | 0.956 | 1.352 |
| t1_irq | jitter | 34 | 27 | 54 | 0.071 | 0.056 | 0.113 |
| t2_handoff | median | 101 | 373 | 425 | 0.210 | 0.777 | 0.885 |
| t2_handoff | p95 | 101 | 382 | 425 | 0.210 | 0.796 | 0.885 |
| t2_handoff | p99 | 101 | 388 | 425 | 0.210 | 0.808 | 0.885 |
| t2_handoff | max | 115 | 541 | 641 | 0.240 | 1.127 | 1.335 |
| t2_handoff | jitter | 15 | 187 | 221 | 0.031 | 0.390 | 0.460 |
| t3_mtx_uncont | median | 62 | 202 | 124 | 0.129 | 0.421 | 0.258 |
| t3_mtx_uncont | p95 | 64 | 214 | 124 | 0.133 | 0.446 | 0.258 |
| t3_mtx_uncont | p99 | 64 | 216 | 124 | 0.133 | 0.450 | 0.258 |
| t3_mtx_uncont | max | 365 | 418 | 442 | 0.760 | 0.871 | 0.921 |
| t3_mtx_uncont | jitter | 303 | 223 | 318 | 0.631 | 0.465 | 0.662 |
| t4_mtx_pi | median | 199 | 599 | 722 | 0.415 | 1.248 | 1.504 |
| t4_mtx_pi | p95 | 199 | 599 | 722 | 0.415 | 1.248 | 1.504 |
| t4_mtx_pi | p99 | 218 | 631 | 766 | 0.454 | 1.315 | 1.596 |
| t4_mtx_pi | max | 218 | 631 | 766 | 0.454 | 1.315 | 1.596 |
| t4_mtx_pi | jitter | 19 | 32 | 44 | 0.040 | 0.067 | 0.092 |
