# Overview - profile `fair_perf`

- publication-gated = yes
- publication mode = dwt_only
- Campaign lock timestamp: 2026-06-18T13:26:35.674456+00:00

**Source attribution - Phase 1 (DWT-only):** every latency number in this report is computed via the DWT cycle counter inside the firmware. TEST 1 corresponds to `A4 - A1` (`ISR_ENTRY -> THREAD_RUNNING`, metric `dwt_a4_minus_a1`); the hardware-event-to-ISR-entry component (timer compare match, NVIC entry, stacking, vectoring, ISR prologue) is EXCLUDED. These figures must NOT be quoted as the external IRQ-to-thread latency or as an LA-equivalent measurement. See ADR-015.

## Configuration snapshot

| field | chibios | freertos | zephyr |
|----|---|---|---|
| kernel | ChibiOS RT 7.0.6 | FreeRTOS V11.3.0 | Zephyr 4.4.0 |
| system_clock | 480000000 Hz | 480000000 Hz | 480000000 Hz |
| vos_level | VOS0 | VOS0 | VOS0 |
| vosrdy | READY | READY | READY |
| flash_acr | 0x00000034 | 0x00000034 | 0x00000034 |
| icache | ON | ON | ON |
| dcache | ON | ON | ON |
| tickless | OFF | OFF | OFF |
| wfi_in_idle | OFF | OFF | OFF |
| optimization | -O2  LTO=no | -O2  LTO=no | -O2  LTO=no |
| elf_sha256 | `f55d8d63...` | `a58a4bc6...` | `6eff9194...` |

## Headline - median-of-medians per (rtos, test)

| rtos     | test          | median (cyc) | median (us) | p99 (cyc) | p99 (us) | run_spread (cyc) | source           |
|----------|---------------|-------------:|------------:|----------:|---------:|-----------------:|------------------|
| chibios  | t1_irq        |          298 |       0.621 |       305 |    0.635 |                0 | DWT              |
| chibios  | t2_handoff    |          101 |       0.210 |       101 |    0.210 |                0 | DWT              |
| chibios  | t3_mtx_uncont |           62 |       0.129 |        64 |    0.133 |                0 | DWT              |
| chibios  | t4_mtx_pi     |          199 |       0.415 |       218 |    0.454 |                0 | DWT              |
| freertos | t1_irq        |          440 |       0.917 |       447 |    0.931 |                0 | DWT              |
| freertos | t2_handoff    |          373 |       0.777 |       388 |    0.808 |                0 | DWT              |
| freertos | t3_mtx_uncont |          202 |       0.421 |       216 |    0.450 |                0 | DWT              |
| freertos | t4_mtx_pi     |          599 |       1.248 |       631 |    1.315 |                0 | DWT              |
| zephyr   | t1_irq        |          624 |       1.300 |       635 |    1.323 |                0 | DWT              |
| zephyr   | t2_handoff    |          425 |       0.885 |       425 |    0.885 |                0 | DWT              |
| zephyr   | t3_mtx_uncont |          124 |       0.258 |       124 |    0.258 |                0 | DWT              |
| zephyr   | t4_mtx_pi     |          722 |       1.504 |       766 |    1.596 |                0 | DWT              |

## TEST 4 priority inheritance

| rtos     | passed / total |
|----------|---------------:|
| chibios  | 500 / 500 |
| freertos | 500 / 500 |
| zephyr   | 500 / 500 |

## Details

- Per-run summaries: `<rtos>_fair_perf_run0[1-5]_summary.md`
- Aggregate: `fair_perf_aggregate.md` / `fair_perf_aggregate.csv`
- Compare: `fair_perf_compare.md`
- Charts: `../plots/fair_perf_*.png`
- Campaign lock: `../manifest/fair_perf_campaign.lock.json`
