# Run summary - chibios / fair_perf / run 01

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `chibios` |
| RTOS kernel | `ChibiOS RT 7.0.6` |
| Profile | `fair_perf` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   285 |    298 |   296 |   303 |   305 |   319 |     34 |      6 |       0.621 |    0.635 |
| t2_handoff    | 10000 |   100 |    101 |   100 |   101 |   101 |   115 |     15 |      0 |       0.210 |    0.210 |
| t3_mtx_uncont | 10000 |    62 |     62 |    62 |    64 |    64 |   365 |    303 |      3 |       0.129 |    0.133 |
| t4_mtx_pi     |   100 |   199 |    199 |   199 |   199 |   218 |   218 |     19 |      1 |       0.415 |    0.454 |

**T4 priority inheritance**: 100 / 100 passed.
