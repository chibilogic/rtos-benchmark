# Cross-RTOS compare - profile `realistic_tickless`

**Source attribution - Phase 1 (DWT-only):** every latency number in this report is computed via the DWT cycle counter inside the firmware. TEST 1 corresponds to `A4 - A1` (`ISR_ENTRY -> THREAD_RUNNING`, metric `dwt_a4_minus_a1`); the hardware-event-to-ISR-entry component (timer compare match, NVIC entry, stacking, vectoring, ISR prologue) is EXCLUDED. These figures must NOT be quoted as the external IRQ-to-thread latency or as an LA-equivalent measurement. See ADR-015.

Median across runs, in cycles. `(us)` columns at the right convert via 480 MHz CPU clock.

## Kernels

| rtos | kernel |
|------|--------|
| chibios | `ChibiOS RT 7.0.6` |
| freertos | `FreeRTOS V11.3.0` |
| zephyr | `Zephyr 4.4.0` |

| test | metric | chibios | freertos | zephyr | chibios (us) | freertos (us) | zephyr (us) |
|----|----|---:|---:|---:|---:|---:|---:|
| t1_irq | median | 306 | 846 | 581 | 0.637 | 1.762 | 1.210 |
| t1_irq | p95 | 322 | 848 | 582 | 0.671 | 1.767 | 1.212 |
| t1_irq | p99 | 324 | 850 | 614 | 0.675 | 1.771 | 1.279 |
| t1_irq | max | 328 | 1027 | 616 | 0.683 | 2.140 | 1.283 |
| t1_irq | jitter | 42 | 202 | 41 | 0.087 | 0.421 | 0.085 |
| t2_handoff | median | 101 | 376 | 424 | 0.210 | 0.783 | 0.883 |
| t2_handoff | p95 | 102 | 397 | 424 | 0.212 | 0.827 | 0.883 |
| t2_handoff | p99 | 102 | 417 | 424 | 0.212 | 0.869 | 0.883 |
| t2_handoff | max | 117 | 566 | 439 | 0.244 | 1.179 | 0.915 |
| t2_handoff | jitter | 17 | 208 | 17 | 0.035 | 0.433 | 0.035 |
| t3_mtx_uncont | median | 62 | 195 | 125 | 0.129 | 0.406 | 0.260 |
| t3_mtx_uncont | p95 | 64 | 195 | 125 | 0.133 | 0.406 | 0.260 |
| t3_mtx_uncont | p99 | 64 | 196 | 125 | 0.133 | 0.408 | 0.260 |
| t3_mtx_uncont | max | 64 | 387 | 140 | 0.133 | 0.806 | 0.292 |
| t3_mtx_uncont | jitter | 2 | 194 | 15 | 0.004 | 0.404 | 0.031 |
| t4_mtx_pi | median | 199 | 612 | 677 | 0.415 | 1.275 | 1.410 |
| t4_mtx_pi | p95 | 199 | 616 | 686 | 0.415 | 1.283 | 1.429 |
| t4_mtx_pi | p99 | 238 | 641 | 715 | 0.496 | 1.335 | 1.490 |
| t4_mtx_pi | max | 238 | 641 | 715 | 0.496 | 1.335 | 1.490 |
| t4_mtx_pi | jitter | 39 | 29 | 38 | 0.081 | 0.060 | 0.079 |
