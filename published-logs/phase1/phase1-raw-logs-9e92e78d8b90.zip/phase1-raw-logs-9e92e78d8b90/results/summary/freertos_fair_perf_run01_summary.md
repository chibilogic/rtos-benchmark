# Run summary - freertos / fair_perf / run 01

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `freertos` |
| RTOS kernel | `FreeRTOS V11.3.0` |
| Profile | `fair_perf` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   432 |    440 |   439 |   447 |   447 |   459 |     27 |      4 |       0.917 |    0.931 |
| t2_handoff    | 10000 |   354 |    373 |   372 |   382 |   388 |   541 |    187 |      8 |       0.777 |    0.808 |
| t3_mtx_uncont | 10000 |   195 |    202 |   205 |   214 |   216 |   418 |    223 |      6 |       0.421 |    0.450 |
| t4_mtx_pi     |   100 |   599 |    599 |   599 |   599 |   631 |   631 |     32 |      3 |       1.248 |    1.315 |

**T4 priority inheritance**: 100 / 100 passed.
