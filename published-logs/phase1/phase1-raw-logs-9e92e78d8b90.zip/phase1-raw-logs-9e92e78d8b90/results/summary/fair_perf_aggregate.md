# Aggregate summary - profile `fair_perf`

Each cell is the **median across the N runs** of that stat field (ADR-013 multi-run rule). A single bad run cannot bias the published number.

CPU clock assumed: 480 MHz

## RTOS kernels (this profile)

| rtos | kernel | consistent across runs |
|------|--------|------------------------|
| chibios | `ChibiOS RT 7.0.6` | yes |
| freertos | `FreeRTOS V11.3.0` | yes |
| zephyr | `Zephyr 4.4.0` | yes |

| rtos     | test          | source           | n_runs | median | p95 | p99 | max | jitter | run_min | run_max | run_spread | mean | stddev | median (us) | p99 (us) |
|----------|---------------|------------------|-------:|-------:|----:|----:|----:|-------:|--------:|--------:|-----------:|-----:|-------:|------------:|---------:|
| chibios  | t1_irq        | DWT              |      5 |    298 | 303 | 305 | 319 |     34 |     298 |     298 |          0 |  296 |      6 |       0.621 |    0.635 |
| chibios  | t2_handoff    | DWT              |      5 |    101 | 101 | 101 | 115 |     15 |     101 |     101 |          0 |  100 |      0 |       0.210 |    0.210 |
| chibios  | t3_mtx_uncont | DWT              |      5 |     62 |  64 |  64 | 365 |    303 |      62 |      62 |          0 |   62 |      3 |       0.129 |    0.133 |
| chibios  | t4_mtx_pi     | DWT              |      5 |    199 | 199 | 218 | 218 |     19 |     199 |     199 |          0 |  199 |      1 |       0.415 |    0.454 |
| freertos | t1_irq        | DWT              |      5 |    440 | 447 | 447 | 459 |     27 |     440 |     440 |          0 |  439 |      4 |       0.917 |    0.931 |
| freertos | t2_handoff    | DWT              |      5 |    373 | 382 | 388 | 541 |    187 |     373 |     373 |          0 |  372 |      8 |       0.777 |    0.808 |
| freertos | t3_mtx_uncont | DWT              |      5 |    202 | 214 | 216 | 418 |    223 |     202 |     202 |          0 |  205 |      6 |       0.421 |    0.450 |
| freertos | t4_mtx_pi     | DWT              |      5 |    599 | 599 | 631 | 631 |     32 |     599 |     599 |          0 |  599 |      3 |       1.248 |    1.315 |
| zephyr   | t1_irq        | DWT              |      5 |    624 | 630 | 635 | 649 |     54 |     624 |     624 |          0 |  615 |     14 |       1.300 |    1.323 |
| zephyr   | t2_handoff    | DWT              |      5 |    425 | 425 | 425 | 641 |    221 |     425 |     425 |          0 |  425 |      6 |       0.885 |    0.885 |
| zephyr   | t3_mtx_uncont | DWT              |      5 |    124 | 124 | 124 | 442 |    318 |     124 |     124 |          0 |  124 |      4 |       0.258 |    0.258 |
| zephyr   | t4_mtx_pi     | DWT              |      5 |    722 | 722 | 766 | 766 |     44 |     722 |     722 |          0 |  722 |      4 |       1.504 |    1.596 |

## T4 priority inheritance - aggregate

| rtos     | passed / total |
|----------|---------------:|
| chibios  | 500 / 500 |
| freertos | 500 / 500 |
| zephyr   | 500 / 500 |
