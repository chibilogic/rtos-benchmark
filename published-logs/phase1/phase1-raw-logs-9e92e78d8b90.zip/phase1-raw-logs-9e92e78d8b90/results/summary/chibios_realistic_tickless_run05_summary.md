# Run summary - chibios / realistic_tickless / run 05

## Run manifest (from banner)

| field | value |
|-------|-------|
| RTOS | `chibios` |
| RTOS kernel | `ChibiOS RT 7.0.6` |
| Profile | `realistic_tickless` |
| Board | `STM32H750B-DK` |
| DBGMCU IDCODE | `0x20036450` |
| SystemClock | `480000000 Hz` |
| VOS level | `VOS0` |
| VOSRDY | `READY` |
| FLASH_ACR | `0x00000034` |
| Optimization | `-O2  LTO=no` |

| test          |     n |   min | median |  mean |   p95 |   p99 |   max | jitter | stddev |  median (us) |  p99 (us) |
|---------------|------:|------:|-------:|------:|------:|------:|------:|-------:|-------:|------------:|----------:|
| t1_irq        | 10000 |   286 |    306 |   305 |   322 |   324 |   328 |     42 |      7 |       0.637 |    0.675 |
| t2_handoff    | 10000 |   100 |    101 |   101 |   102 |   102 |   117 |     17 |      0 |       0.210 |    0.212 |
| t3_mtx_uncont | 10000 |    62 |     62 |    62 |    64 |    64 |    64 |      2 |      0 |       0.129 |    0.133 |
| t4_mtx_pi     |   100 |   199 |    199 |   199 |   199 |   238 |   238 |     39 |      3 |       0.415 |    0.496 |

**T4 priority inheritance**: 100 / 100 passed.
